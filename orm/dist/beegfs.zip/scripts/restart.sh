


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.6.2 "sudo systemctl stop beegfs-client"

ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.3 "sudo systemctl stop beegfs-storage"

ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.2 "sudo systemctl stop beegfs-meta"

ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.4 "sudo systemctl stop beegfs-mgmtd"


****************


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.4 "sudo reboot "

command='ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.4 "hostname"'
while [ $? -ne 0 ];
do
  sleep 10s;
  `$command`
done


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.2 "sudo reboot "

command='ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.2 "hostname"'
`$command`
while [ $? -ne 0 ];
do
sleep 10s;
`$command`
done


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.3 "sudo reboot"


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.3 "hostname"


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.6.2 "sudo reboot"

ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.6.2 "hostname"


***************
ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.4 "sudo systemctl start beegfs-mgmtd ; sudo systemctl status beegfs-mgmtd"


ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.2 "sudo  systemctl start beegfs-meta ; sudo systemctl status beegfs-meta"

Run again:  metadata_tuning.sh

ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.3.3 "sudo systemctl start beegfs-storage ; sudo systemctl status beegfs-storage"

ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio  -o BatchMode=yes -o StrictHostkeyChecking=no  -o ProxyCommand="ssh -i /Users/pvaldria/git_repos/oracle/oci-quickstart-wekaio/terraform/wekaio -o BatchMode=yes -o StrictHostkeyChecking=no opc@150.136.143.117 -W %h:%p %r" opc@10.0.6.2 "sudo systemctl start beegfs-client ; sudo systemctl status beegfs-client"

client node:
sudo beegfs-ctl --setpattern --chunksize=512k --numtargets=1 /mnt/beegfs


TCP window scaling, buffer sizes and timestamps

Update jumbo frames
enable send and receive flow-control on the network cards -  https://www.linux-magazine.com/Issues/2016/182/Ethtool/(offset)/3.    Current flowcontrol is disabled on our NICs.  Do this change only if absolutely necessary.
disable broadcast or storm control settings on your Ethernet switch

